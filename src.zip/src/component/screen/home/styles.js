import {StyleSheet} from 'react-native'

export default styles = StyleSheet.create({
    // homeslide
    container:{
        height : 200,
        width : 300,
        backgroundColor : "#FFF",
        margin:2,
        padding:15
    },

    // hotItem  ht
    ht_container:{
        height : 280,
        width : "50%",
        backgroundColor : "#FFF",
        margin:1,
        padding:15
    }

})

// const styles = StyleSheet.create({

// })

// export default styles;