
import {View,TouchableOpacity,Text,StyleSheet} from "react-native"

const Button = ({
    title,
    onPress
}) => {

    return (
        <TouchableOpacity
            onPress={onPress}
            style={styles.btnContainer}
        >
            <Text style={styles.textButton}>{title}</Text>
        </TouchableOpacity>
    )
}

export default Button

const styles = StyleSheet.create({
    btnContainer:{
        paddingVertical:15,
        backgroundColor : "#000",
        marginTop:10
    },
    textButton:{
        fontWeight:'bold',
        color:'white',
        fontSize:16,
        textAlign:'center'
    }
})