import React from 'react'
import {View,Text as TextRN } from 'react-native'
import styles from './styles'
function Text({
    title="",
    type="defuat", // defuat  | main | title
    pl=0,
    pr=0,
    pt=0,
    pb=0
}) {
    var sty = {}
    switch(type){
        case "defuat" : sty=styles.default; break;
        case "main" : sty=styles.main; break;
        case "title" : sty=styles.title; break;
    }
    sty = {
        ...sty,
        paddingLeft:pl,
        paddingRight:pr,
        paddingTop:pt,
        paddingBottom:pb,
    }
    return (
        <View>
            <TextRN style={sty}>{title}</TextRN>
        </View>
    )
}

export default Text
