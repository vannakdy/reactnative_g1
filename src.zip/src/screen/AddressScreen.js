import React from 'react'
import Layout from '../component/layout/Layout'
import Text from '../component/text/Text'
function AddressScreen() {
  return (
    <Layout>
       <Text title='AddressScreen' type='title' />
    </Layout>
  )
}

export default AddressScreen