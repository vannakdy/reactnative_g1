import React from 'react'
import Layout from '../component/layout/Layout'
import Text from '../component/text/Text'
function EditProfileScreen() {
  return (
    <Layout>
       <Text title='EditProfileScreen' type='title' />
    </Layout>
  )
}

export default EditProfileScreen
