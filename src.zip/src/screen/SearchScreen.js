import {View,Text} from "react-native"

const SearchScreen = () => {

  return (
    <View style={{padding:15}}>
        <Text style={{color:"#000000",fontSize:22}}>Search</Text>
    </View>
  )
}

export default SearchScreen
