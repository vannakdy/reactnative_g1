import React from 'react'
import Layout from '../component/layout/Layout'
import Text from '../component/text/Text'
function ChangePasswordScreen() {
  return (
    <Layout>
       <Text title='ChangePasswordScreen' type='title' />
    </Layout>
  )
}

export default ChangePasswordScreen