import React from 'react'
import Layout from '../component/layout/Layout'
import Text from '../component/text/Text'
function VoucherScreen() {
  return (
    <Layout>
       <Text title='VoucherScreen' type='title' />
    </Layout>
  )
}

export default VoucherScreen