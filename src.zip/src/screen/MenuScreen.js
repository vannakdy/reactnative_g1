import {View,Text,TouchableOpacity} from "react-native"

const MenuScreen = ({navigation}) => {

  const handleGotoSearch = () => {
    navigation.navigate("Search")
  }

  return (
    <View style={{padding:15}}>
        <Text style={{color:"#000000",fontSize:22}}>Menu</Text>
        <TouchableOpacity
          onPress={handleGotoSearch}
        >
          <Text style={{fontSize:20,margin:5}}>Goto Search</Text>
        </TouchableOpacity>
    </View>
  )
}

export default MenuScreen
